const items = [{
		"id": 0,
		"title": "常办事项",
		"img": '../../static/images/itemIcon/icon_item_cbsx.png'
	},
	{
		"id": 1,
		"title": "个人办事",
		"img": '../../static/images/itemIcon/icon_item_grbs.png'
	}, {
		"id": 2,
		"title": "法人办事",
		"img": '../../static/images/itemIcon/icon_item_qybs.png'
	}, {
		"id": 3,
		"title": "常用证照",
		"img": '../../static/images/itemIcon/icon_item_cyzz.png'
	}, {
		"id": 4,
		"title": "网上预约",
		"img": '../../static/images/itemIcon/icon_item_wdyy.png'
	}, {
		"id": 5,
		"title": "进度查询",
		"img": '../../static/images/itemIcon/icon_item_jdcx.png'
	},
	// {
	// 	"id": 6,
	// 	"title": "我的足迹",
	// 	"img": '../../static/images/itemIcon/icon_item_wdzj.png'
	// }, 
	{
		"id": 6,
		"title": "热门事项",
		"img": '../../static/images/itemIcon/icon_item_wdzj.png'
	}, 
	{
		"id": 7,
		"title": "网点导航",
		"img": '../../static/images/itemIcon/icon_item_wddh.png'
	}
];
export default {
	items
}
