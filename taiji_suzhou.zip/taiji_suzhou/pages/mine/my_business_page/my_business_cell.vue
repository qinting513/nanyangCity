<template>
	<view class="contaner">
		<view class="date">2020-06-30 17:44</view>
		<view class="content" @click="$emit('click', item)">
			<view class="item" v-for="(v,k,index) in itemInfo" :key="index">
				<view class="item-title">{{k}}</view>：
				<view class="item-detail">{{v}}</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name:'my_business_cell',
		props:{
			item:{}
		},
		data() {
			return {

			}
		},
		computed:{
			itemInfo() {
				return {
					'业务流水号':this.item.BSNUM,
					'办事事项':this.item.PNAME,
					'办理部门':this.item.DEPTNAME,
					'申请人':this.item.APPLICANT,
					'状态':this.item.CSTATUS
				}
			}
		}
	}
</script>

<style lang="scss">
	.contaner {
		display: flex;
		flex-direction: column;
		margin-top: 35upx;
		align-items: center;
		height: 200px;
		margin-left: 30upx;
		margin-right: 30upx;
		border-radius: 5px;
		margin-bottom: 20upx;
		.date {
			text-align: center;
			font-size: 20upx;
			color: rgb(181,181,181);
			margin-bottom: 30upx;
		}
		.content {
			font-size: 30upx;
			box-shadow: 1px 1px 5px #DDD;
			padding: 20upx;
			width: 100%;
			height: 100%;
			.item {
				display: flex;
				align-items: center;
				margin-top: 10upx;
				.item-title{
					width: 180upx;
					text-align-last: justify;
				}
			}
		}
	}
</style>
